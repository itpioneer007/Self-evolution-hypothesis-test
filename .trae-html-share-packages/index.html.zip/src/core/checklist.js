/*
 * 单题四层 23 条检查项
 * 来源：单题出题检查表.md 第二至第五节
 * 每条都是可二元判定的问句；「挂了」必须写条款号，供记忆库沉淀过程级信号。
 */
(function (root) {
  const SHT = (root.SHT = root.SHT || {});

  SHT.CHECK_LAYERS = [
    {
      id: 'content',
      name: '内容层',
      note: '题本身对不对 · 一票否决',
      items: [
        { id: 'C1', text: '知识点单一、可命名，颗粒度到错因' },
        { id: 'C2', text: '单元归属四查：词表 / 句型表 / 语法进度 / 话题域' },
        { id: 'C3', text: '答案唯一；每个错项都说得出为什么错（审核者说得出即可，不要求解析逐项罗列）' },
        { id: 'C4', text: '题干自洽：条件够、无冗余、无两种读法' },
        { id: 'C5', text: '语言正确：拼写 / 大小写 / 复数 / 连字符与教材一致' },
        { id: 'C6', text: '听力题音文一致' },
        { id: 'C7', text: '语音可读：TTS 不会读错、连读不出歧义' },
        { id: 'C8', text: '配图题图文一致，不能看图就猜对' }
      ]
    },
    {
      id: 'fit',
      name: '适配层',
      note: '对这个学生有没有用 · App 区别于考试之处',
      items: [
        { id: 'F1', text: '冲具体错因，不是冲分数' },
        { id: 'F2', text: '五阶段与题型、层次匹配' },
        { id: 'F3', text: '兴趣载体是他学过的词，没引入生词' },
        { id: 'F4', text: '一题只一个难点，无叠加负荷' },
        { id: 'F5', text: '情绪安全，不指向他上次做错' },
        { id: 'F6', text: '可承受失败：想一想能做出来' }
      ]
    },
    {
      id: 'paper',
      name: '卷面层',
      note: '放进这一轮合不合适 · 只看单题查不出来',
      items: [
        { id: 'P1', text: '与同轮其它题不在同一格' },
        { id: 'P2', text: '相邻题难度差不超过一档' },
        { id: 'P3', text: '同题型不连续超过 2 道' },
        { id: 'P4', text: '单题时长 20–40 秒' },
        { id: 'P5', text: '位置合适：首题给信心，末题不留挫败' }
      ]
    },
    {
      id: 'loop',
      name: '闭环层',
      note: '错了之后能不能被用起来 · 最容易漏',
      items: [
        { id: 'L1', text: '解析教会：错在哪 + 为什么 + 正确是什么，≤25 字' },
        { id: 'L2', text: '错了能归到知识点 id 和错误类型' },
        { id: 'L3', text: '带格子标记，可去重' },
        { id: 'L4', text: '答得出「他错了，下一轮出什么」' }
      ]
    }
  ];

  SHT.ALL_CHECKS = SHT.CHECK_LAYERS.reduce(function (acc, layer) {
    return acc.concat(layer.items.map(function (item) {
      return Object.assign({ layer: layer.id, layerName: layer.name }, item);
    }));
  }, []);

  // 出题手册 3.3 的八条清单 → 界面上的快速质检（与四层检查表并列，不替代）
  SHT.QUALITY_GATE = [
    '不超纲', '答案唯一', '干扰项有诊断价值', '听力和题干一致',
    '拼写口径统一', '难度对画像', '情境适宜', '解析说人话'
  ];

})(window);
